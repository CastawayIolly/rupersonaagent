def LOAD_MODEL():
    pass


def LOAD_CONCEPT_DIST_MATRIX():
    pass


def LOAD_BATCH():
    pass


def CALCULATE_CONCEPT_SET():
    pass


def SET_EXPANSION():
    pass


def EVALUATION():
    pass


# RL
def COSPLAY_PRED():
    pass


def REWARD():
    pass


def LM_REWARD():
    pass


def COMMON_GROUND_REWARD():
    pass


def MUTUAL_BENEFIT_REWARD():
    pass


def PERSONA_RECALL_SCORE():
    pass
