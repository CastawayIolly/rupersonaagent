"""
Export Hugging Face T5 models to protobuf/hdf5 format.
"""
import os
from collections import OrderedDict

import tensorflow as tf
import h5py
import numpy as np
from operator import attrgetter
from lightseq.training.ops.pytorch.export import gather_token_embedding, fill_pb_layer
from export.proto.t5_pb2 import T5 as Transformer
from transformers import T5ForConditionalGeneration
from export.util import parse_args

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"


"""
For the mapping dictionary: key is the value of the proto parameter, value is a powerful expression,
each && split tensor name of the matching path or expression.
The sub-pattern of the path is separated by spaces, and the expression starts with a expression_.
You can operate separately on each tensor and support multiple expressions. Multiple matching paths
and the expression will finally be concatenated on axis = -1.
"""

ENC_LAYER_MAPPING_DICT = OrderedDict(
    {
        "multihead_norm_scale": "zero layer_norm weight",
        "multihead_project_kernel_qkv": "SelfAttention q weight&&SelfAttention k weight&&SelfAttention "
                                        "v weight&&expression_.transpose(0, 1)",
        "multihead_project_kernel_output": "SelfAttention o weight&&expression_.transpose(0, 1)",
        "ffn_norm_scale": "one layer_norm weight",
        "ffn_first_kernel": "DenseReluDense wi weight&&expression_.transpose(0, 1)",
        "ffn_second_kernel": "DenseReluDense wo weight&&expression_.transpose(0, 1)",
    }
)

DEC_LAYER_MAPPING_DICT = OrderedDict(
    {
        "self_norm_scale": "zero layer_norm weight",
        "self_project_kernel_qkv": "SelfAttention q weight&&SelfAttention k weight&&SelfAttention "
                                   "v weight&&expression_.transpose(0, 1)",
        "self_project_kernel_output": "SelfAttention o weight&&expression_.transpose(0, 1)",
        "encdec_norm_scale": "one layer_norm weight",
        "encdec_project_kernel_q": "EncDecAttention q weight&&expression_.transpose(0, 1)",
        "encdec_project_kernel_output": "EncDecAttention o weight&&expression_.transpose(0, 1)",
        "ffn_norm_scale": "two layer_norm weight",
        "ffn_first_kernel": "DenseReluDense wi weight&&expression_.transpose(0, 1)",
        "ffn_second_kernel": "DenseReluDense wo weight&&expression_.transpose(0, 1)",
    }
)

SRC_EMB_MAPPING_DICT = OrderedDict(
    {
        "norm_scale": "final_layer_norm weight",
    }
)

TRG_EMB_MAPPING_DICT = OrderedDict(
    {
        "norm_scale": "final_layer_norm weight",
    }
)


def _get_encode_output_mapping_dict(dec_layer_num):
    encode_output_kernel_pattern = [
        "EncDecAttention {0} k weight&&EncDecAttention {0} v weight".format(ele)
        for ele in range(dec_layer_num)
    ]

    return {
        "encode_output_project_kernel_kv": "&&".join(
            encode_output_kernel_pattern + ["expression_.transpose(0, 1)"]
        )
    }


def save_t5_proto_to_hdf5(transformer: Transformer, f: h5py.File):
    """Convert t5 protobuf to hdf5 format to support larger weight."""
    MODEL_CONF_KEYS = [
        # model_conf
        "head_num",
        "max_step",
        "beam_size",
        "extra_decode_length",
        "length_penalty",
        "src_padding_id",
        "trg_start_id",
        "diverse_lambda",
        "sampling_method",
        "topp",
        "topk",
        "trg_end_id",
        "is_post_ln",
        "no_scale_embedding",
        "use_gelu",
        "is_multilingual",
    ]

    EMBEDDING_KEYS = [
        # src_embedding
        # trg_embedding
        "token_embedding",
        "position_embedding",
        "norm_scale",
        "norm_bias",
        "encode_output_project_kernel_kv",
        "encode_output_project_bias_kv",
        "shared_bias",
        "lang_emb",
        "trg_vocab_mask",
    ]

    ENCODER_LAYER_KEYS = [
        # encoder_stack/{i}
        "multihead_norm_scale",
        "multihead_norm_bias",
        "multihead_project_kernel_qkv",
        "multihead_project_bias_qkv",
        "multihead_project_kernel_output",
        "multihead_project_bias_output",
        "ffn_norm_scale",
        "ffn_norm_bias",
        "ffn_first_kernel",
        "ffn_first_bias",
        "ffn_second_kernel",
        "ffn_second_bias",
    ]

    DECODER_LAYER_KEYS = [
        # decoder_stack/{i}
        "self_norm_scale",
        "self_norm_bias",
        "self_project_kernel_qkv",
        "self_project_bias_qkv",
        "self_project_kernel_output",
        "self_project_bias_output",
        "encdec_norm_scale",
        "encdec_norm_bias",
        "encdec_project_kernel_q",
        "encdec_project_bias_q",
        "encdec_project_kernel_output",
        "encdec_project_bias_output",
        "ffn_norm_scale",
        "ffn_norm_bias",
        "ffn_first_kernel",
        "ffn_first_bias",
        "ffn_second_kernel",
        "ffn_second_bias",
    ]
    base_attr_to_keys = {
        "src_embedding": EMBEDDING_KEYS,
        "trg_embedding": EMBEDDING_KEYS,
        "model_conf": MODEL_CONF_KEYS,
    }

    print("start converting protobuf to hdf5 format.")
    # load src_embedding, trg_embedding, model_conf
    for base_attr, keys in base_attr_to_keys.items():
        for key in keys:
            hdf5_key = f"{base_attr}/{key}"
            proto_attr = f"{base_attr}.{key}"

            if key not in dir(attrgetter(base_attr)(transformer)):
                print(f"key {key} not found in {base_attr}, skipping")
                continue

            print(f"loading transformer {proto_attr} -> {hdf5_key}")
            _data = attrgetter(proto_attr)(transformer)
            if isinstance(_data, str):
                print("find type str, explicitly convert string to ascii encoded array.")
                # explict convert to array of char (int8) to avoid issues on string reading in C
                _data = np.array([ord(c) for c in _data]).astype(np.int8)
            f.create_dataset(hdf5_key, data=_data)

    # save number of layers metadata
    f.create_dataset("model_conf/n_encoder_stack", data=len(transformer.encoder_stack))
    f.create_dataset("model_conf/n_decoder_stack", data=len(transformer.decoder_stack))

    # load encoder_stack
    for layer_id, layer in enumerate(transformer.encoder_stack):
        for key in ENCODER_LAYER_KEYS:
            hdf5_key = f"encoder_stack/{layer_id}/{key}"
            proto_attr = key
            print(f"loading transformer.encoder_stack {proto_attr} -> {hdf5_key}")
            f.create_dataset(hdf5_key, data=attrgetter(proto_attr)(layer))

    # load decoder_stack
    for layer_id, layer in enumerate(transformer.decoder_stack):
        for key in DECODER_LAYER_KEYS:
            hdf5_key = f"decoder_stack/{layer_id}/{key}"
            proto_attr = key
            print(f"loading transformer.decoder_stack {proto_attr} -> {hdf5_key}")
            f.create_dataset(hdf5_key, data=attrgetter(proto_attr)(layer))

    print("proto to hdf5 conversion completed.")


def count_digit(string):
    return sum(1 for char in string if char.isdigit())


def replace_second_digit(string):
    table = {
        "0": "zero",
        "1": "one",
        "2": "two",
        "3": "three",
        "4": "four",
        "5": "five",
    }

    string = list(string)
    pos_digit = -1
    for i in range(len(string)):
        if string[i].isdigit():
            pos_digit = i
    if pos_digit != -1:
        string[pos_digit] = table[string[pos_digit]]
    return "".join(string)


def extract_transformer_weights(
    output_file,
    model_dir,
    head_num,
    generation_method,
    max_step,
    extra_decode_length=50,
    beam_size=4,
    length_penalty: float = 0,
    topk=1,
    topp=0.75,
    only_decoder=True,
    save_proto=False,
):
    transformer = Transformer()
    # load var names
    reloaded = T5ForConditionalGeneration.from_pretrained(model_dir).state_dict()

    encoder_state_dict = {}
    decoder_state_dict = {}
    for k in reloaded:
        new_k = k
        if count_digit(k) >= 2:
            new_k = replace_second_digit(k)
        if k.startswith("encoder."):
            encoder_state_dict[new_k] = reloaded[k]
        elif k.startswith("decoder."):
            decoder_state_dict[new_k] = reloaded[k]
        elif k == "shared.weight":
            encoder_state_dict[new_k] = reloaded[k]
            decoder_state_dict[new_k] = reloaded[k]
        elif k == "final_logits_bias":
            decoder_state_dict[new_k] = reloaded[k]
        else:
            print(new_k)

    dec_var_name_list = list(decoder_state_dict.keys())
    enc_var_name_list = list(encoder_state_dict.keys())

    # fill each encoder layer's params
    if not only_decoder:
        enc_tensor_names = {}
        for name in enc_var_name_list:
            name_split = name.split(".")
            if len(name_split) <= 3 or not name_split[2].isdigit():
                continue
            layer_id = int(name_split[2])
            enc_tensor_names.setdefault(layer_id, []).append(name)

        for layer_id in sorted(enc_tensor_names.keys()):
            fill_pb_layer(
                enc_tensor_names[layer_id],
                encoder_state_dict,
                transformer.encoder_stack.add(),
                ENC_LAYER_MAPPING_DICT,
            )

    # fill each decoder layer's params
    dec_tensor_names = {}
    for name in dec_var_name_list:
        name_split = name.split(".")
        if len(name_split) <= 3 or not name.split(".")[2].isdigit():
            continue
        layer_id = int(name.split(".")[2])
        dec_tensor_names.setdefault(layer_id, []).append(name)

    for layer_id in sorted(dec_tensor_names.keys()):
        fill_pb_layer(
            dec_tensor_names[layer_id],
            decoder_state_dict,
            transformer.decoder_stack.add(),
            DEC_LAYER_MAPPING_DICT,
        )

    # fill src_embedding
    if not only_decoder:
        fill_pb_layer(
            enc_var_name_list,
            encoder_state_dict,
            transformer.src_embedding,
            SRC_EMB_MAPPING_DICT,
        )

        relative_attention_bias_list = (
            encoder_state_dict[
                "encoder.block.0.layer.zero.SelfAttention.relative_attention_bias.weight"
            ]
            .numpy()
            .reshape([-1])
            .tolist()
        )
        transformer.src_embedding.position_embedding[:] = relative_attention_bias_list

        print(
            "encoder.block.0.layer.0.SelfAttention.relative_attention_bias.weight "
            "-> src_embedding.position_embedding, shape: {}, conversion finished!".format(
                encoder_state_dict[
                    "encoder.block.0.layer.zero.SelfAttention.relative_attention_bias.weight"
                ]
                .numpy()
                .shape
            )
        )

        src_tb, _ = gather_token_embedding(
            enc_var_name_list, encoder_state_dict, "shared", scale=False
        )
        transformer.src_embedding.token_embedding[:] = src_tb.flatten().tolist()

    # fill trg_embedding
    encode_output_mapping_dict = _get_encode_output_mapping_dict(len(dec_tensor_names))
    TRG_EMB_MAPPING_DICT.update(encode_output_mapping_dict)

    fill_pb_layer(
        dec_var_name_list,
        decoder_state_dict,
        transformer.trg_embedding,
        TRG_EMB_MAPPING_DICT,
    )

    decoder_relative_attention_bias_list = (
        decoder_state_dict[
            "decoder.block.0.layer.zero.SelfAttention.relative_attention_bias.weight"
        ]
        .numpy()
        .reshape([-1])
        .tolist()
    )

    transformer.trg_embedding.position_embedding[
        :
    ] = decoder_relative_attention_bias_list
    print(
        "decoder.block.0.layer.0.SelfAttention.relative_attention_bias.weight ->"
        " trg_embedding.position_embedding, shape: {}, conversion finished!".format(
            decoder_state_dict[
                "decoder.block.0.layer.zero.SelfAttention.relative_attention_bias.weight"
            ]
            .numpy()
            .shape
        )
    )

    # assert lang in LANG2ID
    trg_tb, _ = gather_token_embedding(
        dec_var_name_list, decoder_state_dict, "shared", scale=False
    )
    transformer.trg_embedding.token_embedding[:] = trg_tb.transpose().flatten().tolist()
    print(
        "token_embedding.weight -> trg_embedding.token_embedding, shape: {}, conversion finished!".format(
            trg_tb.transpose().shape
        )
    )

    # fill in conf

    transformer.model_conf.head_num = head_num
    transformer.model_conf.max_step = max_step
    transformer.model_conf.beam_size = beam_size
    transformer.model_conf.length_penalty = length_penalty

    transformer.model_conf.extra_decode_length = extra_decode_length
    transformer.model_conf.src_padding_id = 0
    transformer.model_conf.trg_start_id = 0
    transformer.model_conf.trg_end_id = 1

    transformer.model_conf.sampling_method = generation_method
    transformer.model_conf.topk = topk
    transformer.model_conf.topp = topp
    transformer.model_conf.diverse_lambda = 0
    transformer.model_conf.is_post_ln = True
    transformer.model_conf.no_scale_embedding = True
    transformer.model_conf.use_gelu = False

    if save_proto:
        output_file += ".pb"
        print("Saving model to protobuf...")
        print("Writing to {0}".format(output_file))
        with tf.io.gfile.GFile(output_file, "wb") as fout:
            fout.write(transformer.SerializeToString())

        transformer = Transformer()
        with tf.io.gfile.GFile(output_file, "rb") as fin:
            transformer.ParseFromString(fin.read())
        print(transformer.model_conf)
    else:
        output_file += ".hdf5"
        print("Saving model to hdf5...")
        print("Writing to {0}".format(output_file))
        f = h5py.File(output_file, "w")
        save_t5_proto_to_hdf5(transformer, f)
        f.close()

        f = h5py.File(output_file, "r")

        def _print_pair(key, value):
            if key == "sampling_method":
                value = "".join(map(chr, value[()]))
            else:
                value = value[()]
            print(f"{key}: {value}")

        list(map(lambda x: _print_pair(*x), f["model_conf"].items()))
        f.close()


if __name__ == "__main__":
    args = parse_args()
    if args.generation_method not in ["beam_search", "topk", "topp", "topk_greedy"]:
        args.generation_method = "beam_search"
    # if save_proto is True, extension .pb will be added, otherwise .hdf5 is added
    output_lightseq_model_name = (
        "lightseq_t5_base"  # you can rename it to "lightseq_t5_large" for large model
    )
    input_huggingface_t5_model = "t5-base"  # Example: you can try "t5-large" as well
    head_number = 12  # change this to 16 for "t5-large" model
    beam_size = 1
    max_step = 80  # max step for generation, it decides GPU memory occupancy
    # maximum_generation_length = min(src_length + extra_decode_length, max_step)
    extra_decode_length = 50
    length_penalty = 1.0
    extract_transformer_weights(
        output_lightseq_model_name,
        input_huggingface_t5_model,
        head_num=head_number,  # layer number
        generation_method=args.generation_method,
        beam_size=beam_size,
        max_step=max_step,
        extra_decode_length=extra_decode_length,
        only_decoder=False,
        length_penalty=length_penalty,
        save_proto=False,
    )
